import React from 'react'

function SubmenuComponent2() {
  return (
    <div>SubmenuComponent2</div>
  )
}

export default SubmenuComponent2