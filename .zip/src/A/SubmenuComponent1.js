import React from 'react'

function SubmenuComponent1() {
  return (
    <div>SubmenuComponent1</div>
  )
}

export default SubmenuComponent1